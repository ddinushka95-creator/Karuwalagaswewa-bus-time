Karuwalagaswewa Bus Time - Phone version

1. Extract this ZIP using Files / My Files.
2. Open karuwalagaswewa_bus_time_demo.html with Chrome.
3. This is a local test version. Data is stored only in this browser on this device.
4. It is not yet a public online app.
